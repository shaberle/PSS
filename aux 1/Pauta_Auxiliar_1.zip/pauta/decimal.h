int decimal(int binario);
